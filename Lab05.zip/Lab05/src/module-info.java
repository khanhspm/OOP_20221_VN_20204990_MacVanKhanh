module Lab05 {
	requires java.desktop;
}
