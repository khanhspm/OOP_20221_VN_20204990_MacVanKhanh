package aims.media;

import aims.exception.PlayerException;

public interface Playable {
	public void play() throws PlayerException;
}
