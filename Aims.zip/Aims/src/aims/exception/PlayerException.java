package aims.exception;

public class PlayerException extends Exception{
    public PlayerException(String message) {
        super(message);
    }

    public PlayerException(){

    }
}